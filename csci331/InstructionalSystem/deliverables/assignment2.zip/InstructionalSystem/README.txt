**** Assignment2 Program ****

1) Overview

Assignment2 is a collection of support classes for an instructional system that admits students, hires instructors, 
offers courses, makes room schedules, and packages course, instructor, and room-schedule as an individual seminar or section.


2) Installation

Copy assignment2.jar to preferred directory.


3) Running the Program

From the correct working directory in a terminal, enter command: 
    java -jar assignment2.jar