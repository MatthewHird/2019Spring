package ca.viu.csci331.instruction.exception;


public class InvalidCourseCreditsException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidCourseCreditsException() {
        super();
    }
}
