package ca.viu.csci331.instruction.exception;


public class InvalidStudentNameException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidStudentNameException() {
        super();
    }
}
