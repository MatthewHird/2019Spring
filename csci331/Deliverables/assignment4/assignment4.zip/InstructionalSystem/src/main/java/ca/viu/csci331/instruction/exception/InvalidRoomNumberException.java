package ca.viu.csci331.instruction.exception;

public class InvalidRoomNumberException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidRoomNumberException() {
        super();
    }
}
