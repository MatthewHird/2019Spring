package ca.viu.csci331.lab6;

public class DivideByZeroRuntimeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DivideByZeroRuntimeException() {
        super();
    }
}
