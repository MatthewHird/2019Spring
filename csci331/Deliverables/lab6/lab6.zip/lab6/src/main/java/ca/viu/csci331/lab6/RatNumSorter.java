package ca.viu.csci331.lab6;

import java.util.ArrayList;

public interface RatNumSorter {
    public void sortAscending(ArrayList<RationalNumber> ratNumList);
    
    public void sortDescending(ArrayList<RationalNumber> ratNumList);
}
