package ca.viu.csci331.instruction.exception;

public class InvalidAdmissionStatusException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidAdmissionStatusException() {
        super();
    }
}
