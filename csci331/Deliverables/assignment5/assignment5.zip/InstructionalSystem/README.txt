**** Assignment5 Program ****

1) Overview

Assignment5 implements Student Service and Instructor Service of the 
Instructional System. Running assignment5.jar will run all of the unit tests 
relating to the Student and Instructor services using junit4. 


2) Installation

Copy assignment5.jar to preferred directory.


3) Running the Program

From the correct working directory in a terminal, enter command: 
    java -jar assignment5.jar