**** Assignment3 Program ****

1) Overview

Assignment3 implements Admission Service of the Instructional System. Running 
assignment3.jar will run all of the unit tests relating to the Admission 
Service using junit4. 


2) Installation

Copy assignment3.jar to preferred directory.


3) Running the Program

From the correct working directory in a terminal, enter command: 
    java -jar assignment3.jar