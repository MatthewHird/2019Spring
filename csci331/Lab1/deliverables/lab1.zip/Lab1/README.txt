**** Lab1 Program ****

1) Overview

The Lab1 program will print a predefined greeting string to STDOUT.


2) Installation

Copy lab1.jar to preferred directory.


3) Running the Program

From the correct working directory in a terminal, enter command: 
    java -jar lab1.jar