package ca.viu.csci331.lab1;

public class AppMain {

	public static void main(String[] args) {
		Greet greeter = new Greet();
		System.out.println(greeter.getText());
	}
}
